<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>

    <h1>PAGO DE SALARIO A EMPLEADOS</h1>
<?php
error_reporting(0);
$empleado = $_POST["empleado"];
$categoria=$_POST['categoria'];
$hora = $_POST["hora"];


?>
    <div class="container">
        <form method="post">
            <div>
                <label>Empleados</label>
                <input type="text" name="empleado"
                value="<?php if(isset($empleado)) echo($empleado)?>"
                >
            </div>
            <div>
                <label>Horas</label>
                <input type="text" name="hora"
                value="<?php if(isset($hora)) echo($hora)?>"
                >
            </div>
            <div>
                <label>Categoria</label>
                <select name="categoria" id="categoria" >
                    <option value="jefe">jefe</option>
                    <option value="administrativo">administrativo</option>
                    <option value="operario">operario</option>
                    <option value="practicante">practicante</option>
                </select>
            </div>
            <input type="submit" value="Procesar" />
            <input type="reset" value="Limpiar" />
        </form>

<?php
if (isset($empleado,$hora)){
    echo($empleado.' <br>' );
    echo($hora.'<br>' );
    echo($categoria.'<br>' );
    
    if($categoria === "jefe"){
        $bruto = $hora * 50;
    }else if($categoria === "administrativo"){
        $bruto = $hora * 30;
    }else if($categoria === "operario"){
        $bruto = $hora * 15;
    }else if($categoria === "practicante"){
        $bruto = $hora * 5;
    }
    $descuento = $bruto * .15;
    $neto = $bruto - $descuento;
    echo('$'.number_format($bruto,2,".",",").' <br>' );
    echo('$'.number_format($descuento,2,".",",").'<br>' );
    echo('$'.number_format($neto,2,".",",").'<br>' );
}

?>
    </div>

</body>
</html>