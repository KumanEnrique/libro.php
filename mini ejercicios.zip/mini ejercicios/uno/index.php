<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>
<?php
error_reporting(0);
$pesos=$_POST['pesos'];
$dolares=$_POST['dolares'];
$libras=$_POST['libras'];
$total=(($dolares*18.83)+$pesos+($libras*24.69));
?>

    <h1>Desarrollo de aplicaciones web con PHP</h1>
    <div class="container">
        <form action="" method="POST">
            <div>
                <label for="pesos">pesos</label>
                <input type="number" name="pesos" id="pesos">
            </div>
            <div>
                <label for="dolares">dolares</label>
                <input type="number" name="dolares" id="dolares">
            </div>
            <div>
                <label for="libras">libras</label>
                <input type="number" name="libras" id="libras">
            </div>
            <input type="submit" value="Procesar" />
            <input type="reset" value="Limpiar" />
        </form>

        <br>
        Total pesos: <?php echo "$ ".number_format($pesos, 2);?> <br>
        Total dólares: <?php echo number_format($dolares, 2)." dolares ";?> <br>
        Total libras: <?php echo number_format($libras, 2)." libras";?> <br>
        Monto total en pesos: <?php echo number_format($total, 2)." total<br>"?>
    </div>

</body>
</html>