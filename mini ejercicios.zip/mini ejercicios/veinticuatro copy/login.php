<?php
session_start();
$nombre = $_POST['nombre'];
$pass = $_POST['pass'];
if ($nombre == 'abc' and $pass == '123') {
    $_SESSION['admin'] = $nombre;
} else {
    $_SESSION['error'] = 'Usuario incorrecto';
}

header('location:index.php');
