<?php
//Iniciando la sesión
session_start();
//Comprobando si la variable libro tiene valor en la sesión
if (isset($_SESSION['libro'])) {
    $unLibro = $_SESSION['libro'];
    echo 'La sesión esta llena y contiene > ' . $unLibro;
} else {
    echo 'La sesión se encuentra vacía';
    $_SESSION['libro'] = 'Tradiciones Peruanas';
}