<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>

    <h1>PAGO DE SALARIO A EMPLEADOS</h1>
<?php
error_reporting(0);
$cliente = $_POST["cliente"];
$monto = $_POST['monto'];
$ticket = $_POST['ticket'];

?>
    <div class="container">
        <form method="post">
            <div>
                <label>Nombre del cliente</label>
                <input type="text" name="cliente"
                value="<?php if(isset($cliente)) echo($cliente);?>"
                >
            </div>
            <div>
                <label>Monto total</label>
                <input type="text" name="monto"
                value="<?php if(isset($monto)) echo($monto);?>"
                >
            </div>
            <div>
                <label>Numéro de ticket</label>
                <input type="text" name="ticket"
                value="<?php if(isset($ticket)) echo($ticket);?>"
                >
            </div>
            <input type="submit" value="Procesar" />
        </form>        
<?php
if(isset($cliente,$monto,$ticket)){
    $cancelar;
    $obsequio;
    switch($ticket){
        case $ticket > 0 && $ticket < 5:
            $obsequio = "Canasta de productos diversos";
            $cancelar = $monto - ($monto * .16);
        break;
        case $ticket > 4 && $ticket < 10:
            $obsequio = "Saco de azucar de 50kg";
            $cancelar = $monto - ($monto * .13);
        break;
        case $ticket > 9 && $ticket < 15:
            $obsequio = "Aceite de 5 litros";
            $cancelar = $monto - ($monto * .06);
        break;
        case $ticket > 14 && $ticket < 20:
            $obsequio = "Caja de leche de 24 latas grandes";
            $cancelar = $monto - ($monto * .12);
        break;
        case $ticket == 20:
            $obsequio = "Saco de arroz de 50kg";
            $cancelar = $monto - ($monto * .10);
        break;
    }
}else{
    echo '<script>
    alert("Ticket No valido..!!");
    </script>';
}

?>
Monto a cancelar :<?php if(isset($cancelar)) echo($cancelar);?><br>
Obsequio obtenido :<?php if(isset($obsequio)) echo($obsequio);?>
    </div>

</body>
</html>