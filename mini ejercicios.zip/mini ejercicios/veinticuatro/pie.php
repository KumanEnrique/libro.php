<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
</head>
<body>
<p id="centrado">
<a href="principal.php">Principal</a> |
<a href="#">Registro del nuevo clientes</a> |
<a href="#">Listado de clientes</a> |
<a href="javascript:close()">Salir</a>
</p>
</body>
</html>