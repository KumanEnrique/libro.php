<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="estilo.css" rel="stylesheet">
    </head>
<body>
    <section>
        <form name="frmColores" method="POST" action="index.php">
            <table width="400" height="120"
            cellspacing="10" cellpadding="0">
                <tr>
                    <td>
                    <table width="200" cellspacing="0" cellpadding="0">
                        <tr>
                            <td>Seleccione color de fondo</td>
                        </tr>
                        <tr>
                            <td><select name="selFondo" onchange="this.form.submit()">
                                    <option>(Seleccione)</option>
                                    <option>Azul</option>
                                    <option>Verde</option>
                                    <option>Rojo</option>
                                    <option>Negro</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    </td>
                    <?php
                    error_reporting(0);
                    session_start();
                    $colores=array(
                    'Azul'=>'#0000FF',
                    'Verde'=>'#00FF00',
                    'Rojo'=>'#FF0000',
                    'Negro'=>'#000000');
                    $color=$_POST['selFondo'];
                    $_SESSION['fondo']=$colores[$color];
                    $fondo = $_SESSION['fondo'] ;
                    ?>
                    <td bgcolor="<?php echo $fondo; ?>">
                    El color seleccionado es: <?php echo $color; ?>
                    </td>
                </tr>
            </table>
        </form>
    </section>
</body>
</html>