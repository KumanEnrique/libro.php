<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
</head>
<body>
<p id="centrado">
<a href="index.php">Principal</a> |
<a href="registro.php">Registro del nuevo cliente</a> |
<a href="listado.php">Listado de clientes</a> |
</p>
</body>
</html>