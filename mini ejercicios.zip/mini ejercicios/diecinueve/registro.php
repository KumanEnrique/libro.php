<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Registro de Clientes</title>
<link href="estilo.css" rel="stylesheet">
</head>
<body>
    <header>
    <?php require 'cabecera.php';?>
        <h2 id="centrado">REGISTRO DEL NUEVO CLIENTE</h2>
    </header>
    <section>
        <form name="frmRegistro" method="POST">
            <table border="1" width="550" cellspacing="5" cellpadding="0">
                <tr>
                    <td>No REGISTRO</td>
                    <td>
            <?php
            error_reporting(0);
            require 'generaCodigo.php';
            $clientes = 'clientes.txt';
            $numero = contador($clientes);
            echo $numero;
            ?>
                    </td>
                </tr>
                <tr>
                    <td>CLIENTE</td>
                    <td><input type="text" name="cliente" size="60" /></td>
                </tr>
                <tr>
                    <td>DIRECCION</td>
                    <td><input type="text" name="direccion" size="60" /></td>
                </tr>
                <tr>
                    <td>TELEFONO</td>
                    <td><input type="text" name="telefono" size="20" /></td>
                </tr>
                <tr>
                    <td>FECHA NAC.</td>
                    <td><input type="text" name="fecha" size="20" /></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="REGISTRAR CLIENTE" name="btnRegistrar" /></td>
                </tr>
            </table>
        </form>
        <?php
        if(isset($_POST["btnRegistrar"])){
            $cli = $_POST['cliente']."<br>";
            $dir = $_POST['direccion']."<br>";
            $tel = $_POST['telefono']."<br>";
            $fec = $_POST['fecha']."<br>";
            
            include 'grabar.php';
            registra($numero, $cli, $dir, $tel, $fec);
        }
        ?>
    </section>
    <footer>
    <?php require 'pie.php'; ?>
    </footer>
</body>
</html>