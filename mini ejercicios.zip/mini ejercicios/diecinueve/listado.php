<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Listado de Clientes</title>
<link href="estilo.css" rel="stylesheet">
</head>
<body>
    <header>
    <?php require 'cabecera.php';?>
        <h2 id="centrado">LISTADO DE CLIENTES</h2>
    </header>
    <section>
        <table border="1" width="550" cellspacing="0" cellpading="0">
            <tr>
                <td>CODIGO</td>
                <td>NOMBRE DEL CLIENTE</td>
                <td>DIRECCION</td>
                <td>TELEFONO</td>
                <td>FECHA NACIMIENTO</td>
            </tr>
            <tr>
        <?php
        $clientes = fopen('clientes.txt','r');
        if(filesize('clientes.txt')==0)
            echo '<p id="centrado">No hay registros..!!</p>';
        else {
            $leer = fread($clientes, filesize('clientes.txt'));
            $linea = explode(chr(13).chr(10),$leer);
            for ($i=0;$i<count($linea)-1;$i++){
                $palabra = explode('|',$linea[$i]);
        ?>
        <td><?php echo $palabra[0]; ?></td>
        <td><?php echo $palabra[1]; ?></td>
        <td><?php echo $palabra[2]; ?></td>
        <td><?php echo $palabra[3]; ?></td>
        <td><?php echo $palabra[4]; ?></td>
        </tr>
        <?php
            }
        }
        ?>
    </table>
    </section>
    <footer>
    <?php require 'pie.php'; ?>
    </footer>
</body>
</html>