<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>CONTROL DE CLIENTES</title>
<link href="estilo.css" rel="stylesheet">
</head>
<body>
    <header>
    <?php require 'cabecera.php'; ?>
    </header>
    <section>
        <table border="1" width="550" cellspacing="5">
            <tr>
                <td><a href="registro.php">Registro de clientes</a></td>
            </tr>
            <tr>
                <td><a href="listado.php">Listado de Clientes</a></td>
            </tr>
        </table>
    </section>
    <footer>
    <?php require 'pie.php'; ?>
    </footer>
</body>
</html>