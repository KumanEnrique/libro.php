<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
<link href="estilo.css" rel="stylesheet">
</head>
<body>
<h3 id="centrado">ENCUESTA DE INSEGURIDAD DEL CIUDADANO
EN LA CIUDAD DE LIMA
</h3>
</body>
</html>