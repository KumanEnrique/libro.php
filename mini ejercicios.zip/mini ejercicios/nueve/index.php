<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>

    <h1>Promedio de notas</h1>
<?php
error_reporting(0);
$alumno = $_POST['alumno'];
$cal1 = $_POST['cal1'];
$cal2 = $_POST['cal2'];
$cal3 = $_POST['cal3'];
$cal4 = $_POST['cal4'];
?>
    <div class="container">
        <form method="post">
            <div>
                <label>Alumno</label>
                <input type="text" name="alumno" 
                value="<?php echo ($alumno);?>"
                >
            </div>
            <div>
                <label>Calificación 1</label>
                <input type="number" name="cal1" 
                value="<?php echo ($cal1);?>"
                >
            </div>
            <div>
                <label>Calificación 2</label>
                <input type="number" name="cal2" 
                value="<?php echo ($cal2);?>"
                >
            </div>
            <div>
                <label>Calificación 3</label>
                <input type="number" name="cal3" 
                value="<?php echo ($cal3);?>"
                >
            </div>
            <div>
                <label>Calificación 4</label>
                <input type="number" name="cal4" 
                value="<?php echo ($cal4);?>"
                >
            </div>
            <input type="submit" value="Promediar" />
        </form>
<?php
$notas = array($cal1,$cal2,$cal3,$cal4);
$min = min($notas);
$max = max($notas);
$promedio = ($cal1 + $cal2 + $cal3 + $cal4)/4;
?>
        <h3>Alumno:<?php if(!empty($alumno)) echo $alumno;?></h3>
        <h3>Promedio:<?php if(!empty($promedio)) echo $promedio;?></h3>
        <h3>Nota más alta:<?php if(!empty($max)) echo $max;?></h3>
        <h3>Nota más baja:<?php if(!empty($min)) echo $min;?></h3>
        <h3>Condición:<?php $promedio >= 6? print("Aprobado"): print("Reprobado");?></h3>
    </div>
</body>
</html>