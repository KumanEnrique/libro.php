<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>

    <h1>Informe de notas -indexado</h1>
<?php
error_reporting(0);
$alumnos = getAlumnos();
$promedio = getPromedio();
?>
    <div class="container">
    <h5>Orden----->Alumno----->Promedio</h5>
    <?php
    for ($i = 0;$i<getConteo();$i++){
        echo ($i+1)."----->".$alumnos[$i]."----->".$promedio[$i]."<br>";
    }
    ?>
        <form method="post">
            <input type="submit" value="Procesar" name="btnMostrar"/>
        </form>
        <?php
        if(isset($_POST["btnMostrar"])){
        ?>
        <table border="2">
            <thead>
                <th>Total de alumnos</th>
                <th>Total de aprobados</th>
                <th>Total de desaprobados</th>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo getConteo();?></td>
                    <td><?php echo get_ap_des()[0];?></td>
                    <td><?php echo get_ap_des()[1];?></td>
                </tr>
            </tbody>
        </table>
        <table border="2">
            <thead>
                <th>Alumno con mayor promedio</th>
                <th>Alumno con menor promedio</th>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo alumnoMinMax()[0];?></td>
                    <td><?php echo alumnoMinMax()[1];?></td>
                </tr>
            </tbody>
        </table>
        <?php }?>
    </div>

<?php 
function getAlumnos(){
    return(array( "Luis Lázaro", "Ángela Torres", "Fernanda Lázaro", "Manuel Torres", "Lucero Mendoza", "Alejandra Menor", "Victoria Bautista", "Francisco Malaver" ));
}
function getPromedio(){
    return (array(17,18,20,19,14,16,12,11) );
}
function getConteo(){
    return(count(getAlumnos()));
}
function get_ap_des(){
    $aprobados = 0;
    $desaprobados = 0;
    for($i=0;$i<getConteo();$i++){
        if(getPromedio()[$i] < 13){
            $desaprobados++;
        }else{
            $aprobados++;
        }
    }
    return array($aprobados,$desaprobados);
}
function minProm(){
    return min(getPromedio());
}
function maxProm(){
    return max(getPromedio());
}
function alumnoMinMax(){
    $maximo = array_search(maxProm(),getPromedio());
    $minimo = array_search(minProm(),getPromedio());
    $alumnoMaximo = getAlumnos()[$maximo];
    $alumnoMinimo = getAlumnos()[$minimo];
    return array($alumnoMaximo,$alumnoMinimo);
}
?>
</body>
</html>