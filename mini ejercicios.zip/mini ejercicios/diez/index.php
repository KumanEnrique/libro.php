<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>

    <h1>Venta de productos(por función)</h1>
<?php
error_reporting(0);
$precio ;
$descuento;
function getCantidad(){
    return $_POST['cantidad'];
}
function getProducto(){
    return $_POST['producto'];
}
function getDay1(){
    return (date("d-m-y"));
}
function getTime1(){
    return (date("H:i"));
}
switch($_POST['producto']){
    case "teclado":
        $precio = 20;
    break;
    case "mouse":
        $precio = 30;
    break;
    case "impresora":
        $precio = 120;
    break;
    case "dd":
        $precio = 170;
    break;
    case "lectora":
        $precio = 25;
    break;
}
function subtotal(){
    $cantidad = getCantidad();
    settype($cantidad,'integer');
    $pr = $GLOBALS['precio'];
    return ($pr * $cantidad);
}
$subtotal = subtotal();
switch ($subtotal ) {
    case $subtotal < 300:
        $descuento  = .08;
    break;
    case $subtotal >= 300 && $subtotal < 500:
        $descuento  = .20;
    break;
    case $subtotal > 500:
        $descuento  = .30;
    break;
}
?>
    <div class="container">
        <form method="post">
            <div>
                <label>Producto</label>
                <select name="producto" >
                <option value="teclado">Teclado multimedia</option>
                <option value="mouse">Mouse optico</option>
                <option value="impresora">Impresora a color</option>
                <option value="dd">Disco duro</option>
                <option value="lectora">Lectora dvd</option>
                </select>
            </div>
            <div>
                <label>Cantidad</label>
                <input type="number" name="cantidad" 
                value="<?php echo getCantidad();?>"
                >
            </div>
            <input type="submit" value="Procesar" />
        </form>
        <h4>Fecha : <?php echo(date("d-m-y"));?></h4>
        <h4>Hora : <?php echo(date("H:i"));?></h4>
        <h2>Precio : <?php echo"$".(number_format($precio,2) );?></h2>
<?php

if(!empty(getProducto()) && !empty(getCantidad())){
?>
        <h3>Fecha:<?php echo getDay1();?></h3>
        <h3>Hora:<?php echo getTime1();?></h3>
        <h3>Producto:<?php echo getProducto();?></h3>
        <h3>Cantidad:<?php echo getCantidad()?></h3>
        <h3>Precio:<?php echo"$".(number_format($precio,2) );?></h3>
        <h3>Subtotal:<?php echo"$".(number_format(subtotal(),2) ); ?></h3>
        <h3>Descuento:<?php echo ($descuento * 100)."%";?></h3>
        <h3>Total:<?php echo "$".(number_format($subtotal - ($subtotal * $descuento),2)) ;?></h3>
    </div>
<?php }
?>
</body>
</html>