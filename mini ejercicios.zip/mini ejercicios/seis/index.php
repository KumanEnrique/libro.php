<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>

    <h1>Mensualidad de Universidad</h1>
<?php
error_reporting(0);
$alumno = $_POST["alumno"];
$categoria = $_POST['categoria'];
$promedio = $_POST['promedio'];
?>
    <div class="container">
        <form method="post">
            <div>
                <label>Nombre del alumno</label>
                <input type="text" name="alumno"
                value="<?php if(isset($alumno)) echo($alumno);?>"
                >
            </div>
            <div>
                <label>Seleccione categoría</label>
                <select name="categoria">
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>
                </select>
            </div>
            <div>
                <label>Ingrese promedio</label>
                <input type="number" name="promedio"
                value="<?php if(isset($promedio)) echo($promedio);?>"
                >
            </div>
            <input type="submit" value="Procesar" />
        </form>        
<?php
if(!empty($promedio)){
    $mensualidad;
    $descuento;
    switch($categoria){
        case 'A' :
            $mensualidad = 850;
        break;
        case 'B':
            $mensualidad = 750;
        break;
        case 'C':
            $mensualidad = 650;
        break;
        case 'D':
            $mensualidad = 500;
        break;
    }
    switch($promedio){
        case $promedio > 12 && $promedio < 16 :
            $descuento = $mensualidad * .10;
        break;
        case $promedio > 15 && $promedio < 18:
            $descuento = $mensualidad * .15;
        break;
        case $promedio > 18 && $promedio < 20:
            $descuento = $mensualidad * .25;
        break;
        case $promedio == 20 :
            $descuento = $mensualidad * .50;
        break;
        default :
            $descuento = 0;
    }
}else{
    echo '<script>
    alert("Ticket No valido..!!");
    </script>';
}

?>
Monto mensualidad :<?php  echo($mensualidad);?><br>
Monto descuento :<?php  echo($descuento);?><br>
Monto a pagar :<?php if(isset($descuento)) echo($mensualidad - $descuento);?><br>
    </div>

</body>
</html>