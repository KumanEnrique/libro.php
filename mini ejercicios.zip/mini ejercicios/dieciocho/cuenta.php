<?php
function contador($archivo){
    $fp = fopen($archivo, 'r+');
    $num = fgets($fp);
    echo 'Usted es el visitante numero: '.$num;
    $num++;
    rewind($fp);
    fwrite($fp, $num); 
}
?>