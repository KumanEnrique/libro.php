<?php
require ('cabecera.php');
require ('cuerpo.php');
require ('pie.php');

?>