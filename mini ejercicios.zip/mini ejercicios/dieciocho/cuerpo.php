<body>
    <h2>contado de visitas basico</h2>
<?php
$visita = "contador.txt";
include('cuenta.php');
contador($visita);
?>
</body>