<?php
//Especifi car la carpeta de donde se analizara su contenido
$carpeta = '/opt/lampp/htdocs/fg/mini ejercicios/diecisiete';
//Obtener sus archivos
$archivos = scandir($carpeta);
//Listar los archivos con sus respectivos tamaños
foreach ($archivos as $campo) {
if (is_file("$carpeta/$campo") &&
$campo != '.' && $campo != '..') {
echo "$campo - ".filesize("$carpeta/$campo")."b<br>";
}
}
?>