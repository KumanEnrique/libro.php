<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>

    <h1>Pension de estudiantes</h1>
<?php
error_reporting(0);
$categoria;
$monto;
$alumno = function (){
    return $_POST['alumno'];
};
$promedio = function (){
    return $_POST['promedio'];
};
$cuotas = function(){
    return 5;
};
?>
    <div class="container">
        <form method="post">
            <div>
                <label>Alumno</label>
                <input type="text" name="alumno" 
                value="<?php ;?>"
                >
            </div>
            <div>
                <label>Promedio</label>
                <input type="number" name="promedio" 
                value="<?php ;?>"
                >
            </div>
            <input type="submit" value="Procesar" />
        </form>
<?php
switch ($promedio()) {
    case $promedio() > 17:
        $categoria = "A";
    break;
    case $promedio() > 14 && $promedio() <= 17 :
        $categoria = "B";
    break;
    case $promedio() > 12 && $promedio() <= 14:
        $categoria = "C";
    break;
    case $promedio() <=12:
        $categoria = "D";
    break;
}
switch ($categoria) {
    case 'A':
        $monto = 550;
    break;
    case 'B':
        $monto = 650;
    break;
    case 'C':
        $monto = 750;
    break;
    case 'D':
        $monto = 800;
    break;
}
if(!empty($promedio()) && !empty($alumno()) )
{
?>
        <h3>Alumno:<?php echo $alumno();?></h3>
        <h3>Promedio:<?php echo $promedio();?></h3>
        <h3>Categoria:<?php echo $categoria;?></h3>
        <hr>
        <h2>RESUMEN DE CUOTAS</h2>
        <h3>Monto pensión:<?php echo "$".number_format($monto,2);?></h3>
        <h3>Fecha actual:<?php echo date('d-m-y');?></h3>
        <h3>Número de cuotas:<?php echo $cuotas(); ?></h3>
        <hr>
        <h2>RESUMEN DE CUOTAS Y FECHAS</h2>
        <h3>Fechas ------->Cuotas</h3>
        <?php 
        for($i = 1;$i <= 5;$i++){
            $f=strtotime("+$i month");
            echo date('d/m/Y',$f)."------->".$monto.'<br>';
        }
        ?>
        <h3>Total por semestre -------> <?php echo "$".(number_format(($cuotas() * $monto),2));?></h3>
<?php }?>
    </div>
</body>
</html>