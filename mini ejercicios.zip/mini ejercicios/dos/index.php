<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>
<?php
error_reporting(0);
$empleado=$_POST['empleado'];
$horas=$_POST['horas'] ;
$tarifa=$_POST['tarifa'];
$bruto = $tarifa*$horas;
$essalud = $bruto * .12;
$afp = $bruto*.10;
$neto = $bruto-($essalud+$afp);
?>
    <div class="container">
        <form method="post">
            <div>
                <label>Empleado</label>
                <input type="text" name="empleado">
            </div>
            <div>
                <label>Horas trabajadas</label>
                <input type="text" name="horas">
            </div>
            <div>
                <label>Tarifa por hora</labe>
                <input type="text" name="tarifa">
            </div>
            <input type="submit" value="Procesar" />
            <input type="reset" value="Limpiar" />
        </form>

        Empleado: <?php echo $empleado;?><br>
        Horas trabajadas: <?php echo $horas;?><br>
        Tarifa por hora: <?php echo $tarifa;?><br>
        Sueldo bruto: <?php echo $bruto;?><br>
        Descuento ESSALUD: <?php echo $essalud;?><br>
        Descuento AFP: <?php echo $afp;?><br>
        Sueldo neto: <?php echo $neto;?>
    </div>

</body>
</html>