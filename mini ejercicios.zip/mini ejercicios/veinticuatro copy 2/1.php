<?php
session_start();
echo "hola ".$_SESSION['admin']."<br>";
print_r($_SESSION);
session_unset();
session_destroy();