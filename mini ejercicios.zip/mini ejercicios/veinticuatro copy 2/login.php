<?php
session_start();
$nombre = $_POST['nombre'];
$pass = $_POST['pass'];
if ($nombre == 'root' and $pass == '123') {
    $_SESSION['admin'] = $nombre;
    header('location:1.php');
} else if($nombre == '1' and $pass == '1'){
    $_SESSION['user'] = "usuario normal";
    header('location:2.php');
}