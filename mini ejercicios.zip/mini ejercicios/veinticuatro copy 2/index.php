<?php
error_reporting(0);
session_start();
?>

<form action="login.php" method="post">
    <input type="text" name="nombre" placeholder="ingresar nombre">
    <input type="text" name="pass" placeholder="ingresar clave">
    <input type="submit" value="ingresar">
</form>
