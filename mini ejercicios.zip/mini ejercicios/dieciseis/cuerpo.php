<body>
    <h3>Manejo de la función require-control de pagos</h3>
    <?php
    error_reporting(0);
$vendedor = $_POST['vendedor'];
$monto = $_POST['monto'];
$descuento;
?>
    <div class="container">
        <form  method="post" >
            <div>
                <label for="vendedor">Vendedor</label>
                <input type="text" name="vendedor" id="vendedor"
                value="<?php if(isset($vendedor))echo $vendedor; ?>"
                >
            </div>
            <div>
                <label for="monto">Monto vendido</label>
                <input type="text" name="monto" id="monto"
                value="<?php if(isset($monto))echo $monto; ?>"
                >
            </div>
            <button type="submit">Procesar</button>
        </form><br><br>
        <?php
require 'procesar.php';
        if(!empty($vendedor) && !empty($monto)){
            echo $monto * $descuento;

        }
        ?>
    </div>
   
</body>