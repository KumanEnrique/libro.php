<?php

switch ($monto) {
    case $monto <= 5000:
        $descuento = .10;
        break;
    case $monto > 5000 && $monto <= 10000:
        $descuento = .20;
        break;
    case $monto > 10000 && $monto <= 15000:
        $descuento = .30;
        break;
    case $monto > 15000:
        $descuento = .50;
        break;
}

