<?php
session_start();
include 'cabecera.php';
error_reporting(0);
$producto = $_POST['selProductos'];
$cantidad = $_POST['cantidad'];
include 'precio.php';
include 'condicion.php';
echo "cantidad total es: ".$cantidadTotal;
echo "<br>precio total es: ".$precioTotal;
echo "<a href='index.php'>volver</a><br><br";
echo "<br><br><a href='destruir.php'>destruir sesion</a><br><br";
