<?php
$precio;
switch ($producto) {
    case 'cafe':
       $precio = 20;
    break;
    case 'pasta':
       $precio = 30;
    break;
    case 'consome':
       $precio = 40;
    break;
    case 'leche':
       $precio = 50;
    break;
    case 'galleta':
       $precio = 60;
    break;
}