<?php
session_start();
session_destroy();
echo "sesion destruida<br>";
echo "<a href='index.php'>ir a inicio</a>";
?>
