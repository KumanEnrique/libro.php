<?php session_start();?>
<body>
    <div class="container">
        <form action="procesar.php" method="post">
            <div>
                <label for="">producto</label>
                <select name="selProductos" >
                    <option value="">selecciona tu producto</option>
                    <option value="cafe">cafe</option>
                    <option value="pasta">pasta</option>
                    <option value="consome">consome</option>
                    <option value="leche">leche</option>
                    <option value="galleta">galleta</option>
                </select>
            </div>
            <div>
                <label for="">cantidad</label>
                <input type="text" name="cantidad" id="">
            </div>
            <button type="submit">procesar</button>
        </form>
    </div>
    <pre>
<?php print_r($_SESSION);?>
    </pre>
</body>
</html>