<?php
if(!isset($_SESSION['productos'])){
    $_SESSION['productos'] = [];
    array_push($_SESSION['productos'],[$producto,$cantidad,$precio]);
}else{
    array_push($_SESSION['productos'],[$producto,$cantidad,$precio]);
}
$productos = $_SESSION['productos'];
for ($i = 0;$i < count($productos);$i++){
    $cantidadTotal += $productos[$i]['1'];

    $product = $productos[$i]['0'];
    $canti = $productos[$i]['1'];
    $precioUnitario = $productos[$i]['2'];
    $subTotal = $canti * $precioUnitario;
    echo $product."----->".$canti."----->".$precioUnitario.
    "----->".$subTotal."<br><br>";
    $precioTotal += $subTotal;
}