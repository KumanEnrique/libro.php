<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>arreglos</title>
</head>
<body>
    <h2>arreglo indexado-paginación de productos</h2>
    <section>
<?php
error_reporting(0);
//Arreglo de productos
$productos = array( 'Lavadora'=>1500,'Radiograbadora'=>500,
    'Licuadora'=>400,'Extractora'=>700,
    'Afeitadora'=>80,'Lampara'=>50,
    'Cocina'=>1300,'Lavavajillas'=>170,
    'Batidora'=>100,'Secadora'=>1000,
    'Tostadora'=>60,'Aspiradora'=>250,
    'Televisor'=>2500,'Campana'=>700,
    'Microondas'=>800,'Plancha'=>150,
    'Calentador'=>1200,'Cafetera'=>50);
//Determinar si hay páginas que mostrar
if (isset($_GET[pagina]))
    $pagina = $_GET[pagina];
else
    $pagina=1;
//Invocar a la función de paginación
paginar($productos, 5, $pagina);
?>
    </section>
</body>
</html>

<?php
//Implementación de la función paginación
function paginar($misProductos, $total, $pagina) {
    //Determinar el total de paginas que genera
    //la cantidad total de productos
    $paginas = ceil(count($misProductos) / $total);
    //Configurando el inicio de la paginación
    $inicio = ($pagina-1)*$total;
    //Configurando la fi nalización de la paginación
    $final = $pagina*$total;
    //Listando los productos en una tabla
    echo '<table border="1" width="700" cellspacing="0" cellpadding="5">';
    echo '<tr>';
    //Obtener los N registros
    $paginado=array_slice($misProductos,$inicio,$final);
    echo "<tr><td>DESCRIPCION DEL PRODUCTO</td>";
    echo "<td>PRECIO DEL PRODUCTO</td></tr>";
    //Listando los productos y sus precios
    for ($i=$inicio; $i<$final; $i++) {
        list($producto,$precio) = each($paginado);
        if (isset($misProductos[$producto])){
            echo "<tr><td>$producto</td>";
            echo "<td>$ ".number_format($precio,2);".</td></tr>";
        }
        else
            break;
    }
        echo '</tr>';
    //Mostrando las paginas
    echo '<tr><td colspan="2" id="centrado">';
    if ($pagina>1)
        echo "<a href=\"?pagina=".($pagina-1)."\">PáginaAnterior<a>&nbsp";
    for ($i=1; $i<=$paginas; $i++) {
        if ($i == $pagina)
            echo "<strong>$i</strong>&nbsp;";
        else
            echo "<a href=\"?pagina=$i\">$i</a>&nbsp;&nbsp;";
    }
    if ($pagina<$paginas)
        echo "<a href=\"?pagina=" . ($pagina+1) ."\">PáginaSiguiente</a>";
        echo '</td></tr>';
        echo '</table>';
        return;
}
?>