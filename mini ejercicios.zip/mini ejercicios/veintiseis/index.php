<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
<link href="estilo.css" rel="stylesheet" >
</head>
<body>

    <section>
        <?php
        error_reporting(0);
        session_start();
        function getProducto()
        {
            return $_POST['selProducto'];
        }
        function getCantidad()
        {
            return $_POST['txtCantidad'];
        }

        $producto = getProducto();
        if($producto=='p001')$selP1='SELECTED'; else $selP1='';
        if($producto=='p002')$selP2='SELECTED'; else $selP2='';
        if($producto=='p003')$selP3='SELECTED'; else $selP3='';
        if($producto=='p004')$selP4='SELECTED'; else $selP4='';
        if($producto=='p005')$selP5='SELECTED'; else $selP5='';
        if($producto=='p006')$selP6='SELECTED'; else $selP6='';
        if($producto=='p007')$selP7='SELECTED'; else $selP7='';
        if($producto=='p008')$selP8='SELECTED'; else $selP8='';
        if($producto=='p009')$selP9='SELECTED'; else $selP9='';
        if($producto=='p010')$selP10='SELECTED'; else $selP10='';
        ?>
        <form name="frmSeleccion"method="POST" action='index.php'>
            <table  width="550" cellspacing="10" cellpadding="1">
                <tr>
                    <td width="200">Seleccione un producto</td>
                    <td width="300">
                        <select name="selProducto" onchange="this.form.submit()">
                            <option value="p001" <?php echo $selP1;?>>Gaseosa</option>
                            <option value="p002" <?php echo $selP2;?>>Mayonesa en sobre</option>
                            <option value="p003" <?php echo $selP3;?>>Chocolate para niños</option>
                            <option value="p004" <?php echo $selP4;?>>Fideos</option>
                            <option value="p005" <?php echo $selP5;?>>Conservas</option>
                            <option value="p006" <?php echo $selP6;?>>Chocolate</option>
                            <option value="p007" <?php echo $selP7;?>>Cafe 300mg.</option>
                            <option value="p008" <?php echo $selP8;?>>Mayonesa pote</option>
                            <option value="p009" <?php echo $selP9;?>>Crema Dental</option>
                            <option value="p010" <?php echo $selP10;?>>Cubito de pollo</option>
                        </select>
                    </td>
                    <td rowspan="3">
            
                        <img src="<?php echo getProducto();?>.jpeg" width="120" height="120"/>
                    </td>
                </tr>
                <tr>
                    <td>Cantidad</td>
                    <td><input type="text" name="txtCantidad" value="" /></td>
                    <td></td>
                </tr>
                <tr>
                    <td><input type="submit" value="Comprar" onclick = "this.form.action = 'canasta.php'" name='btnComprar''/></td>
                    <td></td>
                    <td></td>
                </tr>
            </table>
        </form>
    </section><br><br>

    <p><?php  print_r($_SESSION);?></p>
</body>
</html>