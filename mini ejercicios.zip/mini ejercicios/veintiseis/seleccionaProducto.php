<?php
if($producto=='p001')$selP1='SELECTED'; else $selP1='';
if($producto=='p002')$selP2='SELECTED'; else $selP2='';
if($producto=='p003')$selP3='SELECTED'; else $selP3='';
if($producto=='p004')$selP4='SELECTED'; else $selP4='';
if($producto=='p005')$selP5='SELECTED'; else $selP5='';
if($producto=='p006')$selP6='SELECTED'; else $selP6='';
if($producto=='p007')$selP7='SELECTED'; else $selP7='';
if($producto=='p008')$selP8='SELECTED'; else $selP8='';
if($producto=='p009')$selP9='SELECTED'; else $selP9='';
if($producto=='p010')$selP10='SELECTED'; else $selP10='';
