<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
<link href="estilo.css" rel="stylesheet">
</head>
<body>
    <section>
        <table  width="550" cellspacing="10" cellpadding="0">
            <tr>
                <td>
                    <img src="p002.jpeg" width="80" height="80" />
                </td>
            </tr>
            <tr>
                <th>Codigo</th>
                <th>Descripcion</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Subtotal</th>
            </tr>
<?php
error_reporting(0);
session_start();
function getProducto()
{
    return $_POST['selProducto'];
}
function getCantidad()
{
    return $_POST['txtCantidad'];
}

function asignaPrecio($código)
{
    switch ($codigo) {
        case 'p001':return 1.5;
        case 'p002':return 2.5;
        case 'p003':return 11;
        case 'p004':return 1.5;
        case 'p005':return 5;
        case 'p006':return 22;
        case 'p007':return 18.5;
        case 'p008':return 15;
        case 'p009':return 7.5;
        case 'p010':return 1;
    }
}
function muestraDescripcion($codigo)
{
    switch ($codigo) {
        case 'p001':return 'Gaseosa';
        case 'p002':return 'Mayonesa en sobre';
        case 'p003':return 'Chocolate para niños';
        case 'p004':return 'Fideos';
        case 'p005':return 'Conservas';
        case 'p006':return 'Chocolate';
        case 'p007':return 'Cafe 300mg.';
        case 'p008':return 'Mayonesa pote';
        case 'p009':return 'Crema Dental';
        case 'p010':return 'Cubito de pollo';

    }
}
$código = getProducto();
$cantidad = getCantidad();
echo 'hola'."<br>";
print_r($_SESSION);
print('hola'."<br>".$productos);
if (!isset($_SESSION[$productos])) {
    $_SESSION[$productos][$código] = $cantidad;} else {
    foreach ($_SESSION[$productos] as $pro => $cant) {
        if ($codigo == $pro) {
            $_SESSION[$productos][$pro] += $cantidad;
            $bandera = 1;
        }
        $total += $cant;
    }
}
if (!$bandera) {
    $_SESSION[$productos][$codigo] = $cantidad;
}

if (isset($_SESSION[$productos])) {
    $tSubtotal = 0;
    foreach ($_SESSION[$productos] as $cod => $cant) {
        $subtotal = $cant * asignaPrecio($cod);
        $tSubtotal += $subtotal;
        ?>
    <tr>
    <td id="centrado"><?php echo $cod; ?></td>
    <td><?php echo muestraDescripcion($cod); ?></td>
    <td id="derecha">
    <?php echo '$' . number_format(asignaPrecio($cod), 2); ?>
    </td>
    <td id="centrado"><?php echo $cant; ?></td>
    <td id="derecha"><?php echo '$' . number_format($subtotal, 2); ?></td>
    </tr>
    <?php
    }
}
?>
            <tr>
                <td id="resaltado">Total a Pagar</td>
                <td></td>
                <td></td>
                <td></td>
                <td id="totales"><?php echo '$' . number_format($tSubtotal, 2); ?></td>
            </tr>
            <tr>
                <td colspan="4"><?php echo '<a href="index.php">
            Seguir comprando..!! </a>'; ?>
                </td>
                <td colspan="4"><?php echo '<a href="destruir.php">
            Finalizar la compra</a>'; ?>
                </td>
            </tr>
        </table>
    </section>
</body>
</html>