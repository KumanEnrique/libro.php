<?php

function exciste($nombre)
{
    if (file_exists($nombre)) {
        return "Nombre completo del archivo: {$nombre}<br>El archivo si existe!!!";
    } else {
        return "no existe";
    }
}
function ultimaModificacion($nombre)
{
    if (file_exists($nombre)) {
        return date("F d Y H:i:s.", filectime($nombre));
    } else {
        return '';
    }

}
function tipoArchivo($nombre)
{
    return filetype($nombre);
}
function tamañoArchivo($nombre)
{
    return filesize($nombre);
}
function esEjecutable($nombre)
{
    if (is_executable($nombre)) {
        return 'Archivo ejecutable';
    } else {
        return 'Archivo NO ejecutable';
    }

}
