<body>
<?php
error_reporting(0);
$nombre = $_POST['nombre'];
include 'procesar.php';
?>
    <div class="container">
        <form method="post">
            <div>
                <label for="nombre">Nombre del archivo:</label>
                <input type="text" name="nombre" id="nombre" autofocus>
            </div>
        </form>
        <?php
error_reporting(0);
$nombre = $_POST['nombre'];
echo exciste($nombre) . "<br>";
echo ultimaModificacion($nombre) . "<br>";
echo tipoArchivo($nombre) . "<br>";
echo tamañoArchivo($nombre) . "<br>";
echo esEjecutable($nombre) . "<br>";
?>
    </div>
</body>