<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>

    <h1>venta de productosdf</h1>
<?php
error_reporting(0);
$categoria = $_POST['categoria'];
$cantidad = $_POST['cantidad'];
$cuotas = $_POST['cuotas'];
$costo;
$total;
?>
    <div class="container">
        <form method="post">
            <div>
                <label>Seleccione categoría</label>
                <select name="categoria" onchange="this.form.submit()">
                    <option >seleccione una opción</option>
                    <option value="lavadora"
                    <?php if($categoria == "lavadora") echo "selected"; ?>
                    >lavadora</option>
                    <option value="refrigeradora"
                    <?php if($categoria == "refrigeradora") echo "selected"; ?>
                    >refrigeradora</option>
                    <option value="radiograbadora"
                    <?php if($categoria == "radiograbadora") echo "selected"; ?>
                    >radiograbadora</option>
                    <option value="tostadora"
                    <?php if($categoria == "tostadora") echo "selected"; ?>
                    >tostadora</option>
                </select>
            </div>
<?php
switch($categoria){
    case 'lavadora' :
        $costo = 1500;
    break;
    case 'refrigeradora':
        $costo = 3500;
    break;
    case 'radiograbadora':
        $costo = 1500;
    break;
    case 'tostadora':
        $costo = 150;
    break;
}
$total = $costo * $cantidad;
?>
            <div>
                <label>Precio por unidad</label>
                <input type="number" name="precio" readonly
                value="<?php echo ($costo);?>"
                >
            </div>
            <div>
                <label>Ingrese cantidad</label>
                <input type="number" name="cantidad"
                value="<?php  echo($cantidad);?>"
                >
            </div>
            <div>
                <label>Total</label>
                <input type="number" name="precio"
                value="<?php echo ($total);?>"
                >
            </div>
            <div>
                <label>Seleccione un no. de cuotas</label>
                <select name="cuotas" onchange="this.form.submit()">
                    <option >seleccione una opción</option>
                    <option value="3">3</option>
                    <option value="6">6</option>
                    <option value="9">9</option>
                    <option value="12">12</option>
                </select>
            </div>
            <input type="submit" value="Procesar" />
        </form>        
<?php if($cuotas == 3 || $cuotas == 6 || $cuotas == 9 || $cuotas == 12){ ?>
<?php  
$i = 1;
$montoMensual = $total / $cuotas;
while($i <= $cuotas){
    echo $i."-->".$montoMensual."<br>";
    $i++;
?>
<?php }?><!-- endwhile -->
<?php } ?><!-- endif -->
    </div>

</body>
</html>