<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>

    <h1>Formulariode registro de empleados</h1>
<?php
error_reporting(0);
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$nacimiento = $_POST['nacimiento'];
$civil = $_POST['civil'];
$sexo = $_POST['sexo'];
$civilN;
$sexoN;
$generado;
?>
    <div class="container">
        <form method="post">
            <div>
                <label>Nombres</label>
                <input type="text" name="nombre" 
                value="<?php echo ($nombre);?>"
                >
            </div>
            <div>
                <label>Apellidos</label>
                <input type="text" name="apellido" 
                value="<?php echo ($apellido);?>"
                >
            </div>
            <div>
                <label>Fecha de nacimiento</label>
                <input type="date" name="nacimiento" 
                value="<?php echo ($nacimiento);?>"
                >
            </div>
            <div>
                <label>Seleccione categoría</label>
                <select name="civil">
                    <option value="soltero"
                    <?php #if($categoria == "lavadora") echo "selected"; ?>
                    >soltero</option>
                    <option value="casado"
                    <?php #if($categoria == "refrigeradora") echo "selected"; ?>
                    >casado</option>
                    <option value="viudo"
                    <?php #if($categoria == "refrigeradora") echo "selected"; ?>
                    >viudo</option>
                    <option value="divorciado"
                    <?php #if($categoria == "refrigeradora") echo "selected"; ?>
                    >divorciado</option>
                </select>
            </div>
            <div>
                <label for="">sexo : </label>
                hombre
                <input type="radio" name="sexo" id="" value="hombre">
                mujer
                <input type="radio" name="sexo" id="" value="mujer">
            </div>
            <input type="submit" value="Generar codigo" />
        </form>
<?php 
echo $nombre;
echo "<br>";
echo $apellido;
echo "<br>";
echo ($nacimiento);
echo "<br>";
echo $civil;
echo "<br>";
switch($civil){
    case "soltero":
        $civilN = 1;
    break;
    case "casado":
        $civilN = 2;
    break;
    case "viudo":
        $civilN = 3;
    break;
    case "divorciado":
        $civilN = 4;
    break;
}
echo $sexo.'<br>';
switch($sexo){
    case "hombre":
        $sexoN = 1;
    break;
    case "mujer":
        $sexoN = 2;
    break;
}
if(!empty($sexo)){
    $año = substr($nacimiento,0,4);
    settype($año,'integer');
    $fechaActual = date('d-m-Y');
    $añoActual = substr($fechaActual,-4);
    settype($añoActual,'integer');
    echo "<h1>CODIGO GENERADO</h1>";
    
    $generado = substr($fechaActual,-2).$civilN.$sexoN.($añoActual - $año);
    echo $generado;
}
?>


    </div>
</body>
</html>