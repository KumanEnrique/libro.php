<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>capitulo 3</title>
    </head>
<body>
<?php
error_reporting(0);
$cantidad=$_POST['cantidad'];
define("PRECIO",20.55);
$compra = $cantidad * PRECIO;
$descuento = $compra * .10;
$neto = $compra - $descuento;
?>
    <div class="container">
        <form method="post">
            <div>
                <label>Cantidad</label>
                <input type="text" name="cantidad">
            </div>
            <input type="submit" value="Procesar" />
            <input type="reset" value="Limpiar" />
        </form>

        Precio: <?php echo PRECIO;?><br>
        Cantidad: <?php echo $cantidad;?><br>
        Importe de compra: <?php echo $compra;?><br>
        Importe de descuento: <?php echo $descuento;?><br>
        Importe neto: <?php echo $neto;?>
    </div>

</body>
</html>