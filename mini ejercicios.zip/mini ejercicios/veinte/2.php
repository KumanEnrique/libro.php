<?php
session_start();
$productos = $_SESSION['misProductos'];
echo 'Los productos del arreglo son: ';
foreach($productos as $producto){
echo $producto.'<br>';
}
echo '<a href="index.php">Enviar información</a><br>';
print_r($_SESSION);
?>