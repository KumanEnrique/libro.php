<?php
session_start();
$productos = array('Lavadora','Refrigeradora',
'DVD','Televisor','Radiograbadora');
$_SESSION['misProductos']=$productos;
echo 'Arreglo de productos enviado a la
session correctamente<br>';
echo '<a href="2.php">Recuperar información</a>';
?>