<body>
    <h3>manejo de la funcion include-Listado de productos</h3>
<?php
$productos = array( 'Lavadora'=>1500,'Radiograbadora'=>500,
    'Licuadora'=>400,'Extractora'=>700,
    'Afeitadora'=>80,'Lampara'=>50,
    'Cocina'=>1300,'Lavavajillas'=>170,
    'Batidora'=>100,'Secadora'=>1000,
    'Tostadora'=>60,'Aspiradora'=>250,
    'Televisor'=>2500,'Campana'=>700,
    'Microondas'=>800,'Plancha'=>150,
    'Calentador'=>1200,'Cafetera'=>50);
?>
    <h4>Descripción del producto----->Precio unitario</h4>
    <?php
    for($i = 0;$i < count($productos);$i++){
        list($clave,$valor) = each($productos);
        echo $clave."----->"." $ ".number_format($valor)."<br>";
    }
    ?>
</body>