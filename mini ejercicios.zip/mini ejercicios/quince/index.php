<?php
include ('cabecera.php');
include ('cuerpo.php');
include ('pie.php');

?>